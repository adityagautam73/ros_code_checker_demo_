Aditya_ROS_Tool - Student Version

This is a student-style version of the Robotics Intern Task submission.

Objective:
Create a system that accepts ROS/ROS2 code, checks for correctness, and shows a simulation preview.

Folders:
- backend/: Python code checker script
- webapp/: Flask web interface
- sample_files/: Demo simulation preview GIF
- test_packages/: One valid and one faulty ROS package

This is simplified for demo purposes and follows the assignment instructions as a student would implement it.
