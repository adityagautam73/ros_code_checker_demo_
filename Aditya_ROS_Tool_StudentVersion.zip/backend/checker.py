# Student version of ROS Code Checker
# Accepts ROS/ROS2 package ZIP and checks syntax + structure + simple safety

import zipfile, os, tempfile, subprocess, json

def run_checks(zip_file):
    temp_dir = tempfile.mkdtemp()
    with zipfile.ZipFile(zip_file, 'r') as zip_ref:
        zip_ref.extractall(temp_dir)
    result = {"errors": [], "warnings": [], "info": []}

    # Syntax check for Python files
    py_files = [os.path.join(root, f)
                for root, _, files in os.walk(temp_dir)
                for f in files if f.endswith(".py")]
    for file in py_files:
        out = subprocess.run(['flake8', file], capture_output=True, text=True)
        if out.stdout:
            result["errors"].append(out.stdout)
        else:
            result["info"].append(f"{file} - syntax OK")

    # Check ROS structure
    if not os.path.exists(os.path.join(temp_dir, "package.xml")):
        result["warnings"].append("Missing package.xml")
    if not any(os.path.exists(os.path.join(temp_dir, f)) for f in ["CMakeLists.txt", "setup.py"]):
        result["warnings"].append("Missing build file")

    # Detect init_node
    code_text = "".join(open(f).read() for f in py_files)
    if "rospy.init_node" not in code_text:
        result["warnings"].append("No init_node found")

    # Save JSON report
    report_path = os.path.join(temp_dir, "report.json")
    with open(report_path, "w") as f:
        json.dump(result, f, indent=4)
    return result
