# Student version Flask App
# Simple interface for ROS code checker demo

from flask import Flask, render_template, request, jsonify, send_file
from backend.checker import run_checks

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    file = request.files['ros_zip']
    result = run_checks(file)
    return jsonify(result)

@app.route('/simulate')
def simulate():
    return send_file('../sample_files/preview.gif', mimetype='image/gif')

if __name__ == '__main__':
    app.run(debug=True)
